---
name: shared
description: ไลบรารีเอกสารอ้างอิงร่วมสำหรับทุก skill ใน camt-arts-research-skills ประกอบด้วย cross_agent_quality_definitions (Quality Standards ที่ใช้ร่วมกัน), handoff_schemas (Format มาตรฐานสำหรับส่งข้อมูลระหว่าง skills), mode_spectrum (คำนิยาม response modes ตั้งแต่ quick ถึง comprehensive), และ tci_compliance_guide (แนวทาง TCI 7 requirements สำหรับทุก skill). Use when you need reference definitions for inter-skill quality standards, handoff protocols, or TCI compliance guidance.
license: MIT
metadata:
  author: CAMT Research Support Unit
  version: 2.0.0
  institution: College of Arts, Media and Technology, Chiang Mai University
  last_updated: "2026-05-05"
  type: shared-library
  used_by:
    - arts-research-pipeline
    - arts-deep-research
    - arts-paper-writer
    - arts-paper-reviewer
    - arts-citation-formatter
    - practice-based-research
    - visual-analysis
---

# Shared Resources Library

ไลบรารีเอกสารอ้างอิงร่วมสำหรับทุก skill ใน camt-arts-research-skills

## ไฟล์ในชุดนี้

| ไฟล์ | วัตถุประสงค์ |
|------|-------------|
| `cross_agent_quality_definitions.md` | Quality Standards ที่ใช้ร่วมกันในทุก skill |
| `handoff_schemas.md` | Format มาตรฐานสำหรับส่งข้อมูลระหว่าง skills |
| `mode_spectrum.md` | คำนิยาม response modes (quick → comprehensive) |
| `tci_compliance_guide.md` | แนวทาง TCI compliance 7 requirements |

## วิธีใช้

Skills อื่นอ้างอิงไฟล์เหล่านี้ผ่าน relative path:

```
../shared/cross_agent_quality_definitions.md
../shared/handoff_schemas.md
../shared/mode_spectrum.md
../shared/tci_compliance_guide.md
```

## ข้อกำหนด

- เอกสารเหล่านี้เป็น **read-only reference** — ห้ามแก้ไขโดยไม่ผ่าน CAMT Research Support Unit
- การอัปเดตทุกครั้งต้องอัปเดต version field ใน frontmatter
- ต้อง sync version กับ skills ที่ใช้งาน

## Version History

| Version | วันที่ | การเปลี่ยนแปลง |
|---------|-------|--------------|
| 2.0.0 | 2026-05-05 | Initial shared library — รวมเอกสารอ้างอิงจาก 7 skills เข้าเป็น library เดียว |
