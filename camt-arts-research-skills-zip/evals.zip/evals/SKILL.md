---
name: evals
description: ชุดทดสอบ (Evaluation Suite) สำหรับ skills ทั้งหมดใน camt-arts-research-skills ครอบคลุม 4 หมวด: trigger_accuracy (ทดสอบว่า skill ถูก trigger ถูกต้อง — positive/negative/edge cases), output_quality (ตรวจ Iron Rules compliance, TCI format, bilingual abstract alignment), failure_paths (ตรวจ FM-A ถึง FM-G detection และ recovery protocol), pipeline_flow (ตรวจ handoff schemas และ State Machine transitions). ใช้ร่วมกับ skill-creator เพื่อรัน automated evals หรือใช้ manual eval โดยส่ง Input Prompt ให้ Claude แล้วเทียบกับ Expected Behavior. Use when you need to test, evaluate, or validate any skill in the camt-arts-research-skills suite.
license: MIT
metadata:
  author: CAMT Research Support Unit
  version: 1.0.0
  institution: College of Arts, Media and Technology, Chiang Mai University
  last_updated: "2026-05-05"
  type: eval-suite
  skills_tested:
    - arts-research-pipeline
    - arts-deep-research
    - arts-paper-writer
    - arts-paper-reviewer
    - arts-citation-formatter
    - practice-based-research
    - visual-analysis
---

# CAMT Arts Research Skills — Evaluation Suite

ชุดทดสอบสำหรับ skills ทั้งหมดใน camt-arts-research-skills

## โครงสร้าง

```
evals/
├── SKILL.md                         ← ไฟล์นี้
├── README.md                        ← คู่มือใช้งาน eval suite
├── trigger_accuracy/
│   ├── positive_cases.md            ← prompts ที่ควร trigger แต่ละ skill
│   ├── negative_cases.md            ← prompts ที่ไม่ควร trigger (false positive test)
│   └── edge_cases.md                ← กรณีกำกวม
├── output_quality/
│   ├── iron_rules_checklist.md      ← ตรวจ Iron Rules ทุกข้อ
│   ├── tci_compliance_cases.md      ← ตรวจ TCI format 7 requirements
│   └── bilingual_abstract_cases.md  ← ตรวจ Thai/English alignment
├── failure_paths/
│   ├── fm_detection_cases.md        ← ตรวจ FM-A ถึง FM-G detection
│   └── recovery_protocol_cases.md   ← ตรวจ recovery workflow
└── pipeline_flow/
    ├── handoff_schema_cases.md      ← ตรวจ inter-skill data transfer
    └── state_machine_cases.md       ← ตรวจ State Machine transitions
```

## วิธีใช้งาน

### Manual Eval

1. เปิดไฟล์ test cases ในโฟลเดอร์ที่ต้องการ
2. คัดลอก **Input Prompt** ส่งให้ Claude
3. เทียบผลลัพธ์กับ **Expected Behavior** และ **Assertion Criteria**
4. บันทึก PASS / FAIL / PARTIAL

### Automated Eval (ใช้ skill-creator)

```
/skill-creator run-eval --suite evals/ --skill arts-paper-writer
```

## Scoring

| Grade | เกณฑ์ |
|-------|--------|
| ✅ PASS | ตรงตาม assertion ทุกข้อ |
| ⚠️ PARTIAL | ตรง 70–99% ของ assertions |
| ❌ FAIL | ต่ำกว่า 70% หรือละเมิด Iron Rule ใดๆ |

> ⚠️ Iron Rule violation = FAIL ทันที ไม่ว่า assertion อื่นจะผ่านหรือไม่

## Baseline Targets

- Trigger accuracy: ≥ 90% precision, ≥ 85% recall  
- Output quality: ≥ 90% Iron Rules compliance  
- Failure path detection: ≥ 85% FM detection rate  
- Pipeline flow: 100% handoff schema completeness
